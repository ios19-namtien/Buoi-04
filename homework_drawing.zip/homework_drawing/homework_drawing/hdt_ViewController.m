//
//  hdt_ViewController.m
//  homework_drawing
//
//  Created by NguyenTien on 11/26/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import "hdt_ViewController.h"

@interface hdt_ViewController ()

@end

@implementation hdt_ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)drawZigZag:(id)sender {
    [self drawDiagonal:10];
}

- (IBAction)drawCar:(id)sender {
}

- (IBAction)drawTree:(id)sender {
}

- (void)drawDiagonal : (int)width
{
    int n;
    int z;
    
    for (n=1; n<=width; n++) {
        for (z=n; z<=width; z++) {
            printf(" ");
        }
        
        printf("/");
        
        if (n==1) {
            printf("\\");
            
            for (z=n; z<width; z++) {
                printf("  ");
            }
            
            printf("/\\\n");
        }
        else{
            for (z=n-1; z>0; z--) {
                printf("  ");
            }
            
            printf("\\");
            
            for (z=n; z<width; z++) {
                printf("  ");
            }
            
            printf("/");
            
            for (z=n-1; z>0; z--) {
                printf("  ");
            }
            
            printf("\\\n");
        }
    }
    printf("\n");
}





@end
